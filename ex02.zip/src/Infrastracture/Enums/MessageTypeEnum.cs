﻿namespace Infrastracture.Enums
{
    public enum MessageTypeEnum : int
    {
        INFO = 4,
        WARNING = 2,
        FAIL = 1
    } 
}
